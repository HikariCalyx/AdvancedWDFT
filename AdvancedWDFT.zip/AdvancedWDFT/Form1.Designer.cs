﻿namespace AdvancedWDFT
{
    partial class thor2gui
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.uefiflash = new System.Windows.Forms.GroupBox();
            this.emergency = new System.Windows.Forms.GroupBox();
            this.rnd = new System.Windows.Forms.GroupBox();
            this.etc = new System.Windows.Forms.GroupBox();
            this.type = new System.Windows.Forms.ComboBox();
            this.uefiflashlocation = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.uefibrowse = new System.Windows.Forms.Button();
            this.skipsigchk = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.uefiflash.SuspendLayout();
            this.emergency.SuspendLayout();
            this.rnd.SuspendLayout();
            this.etc.SuspendLayout();
            this.SuspendLayout();
            // 
            // uefiflash
            // 
            this.uefiflash.Controls.Add(this.checkBox8);
            this.uefiflash.Controls.Add(this.checkBox7);
            this.uefiflash.Controls.Add(this.label1);
            this.uefiflash.Controls.Add(this.checkBox4);
            this.uefiflash.Controls.Add(this.textBox2);
            this.uefiflash.Controls.Add(this.checkBox3);
            this.uefiflash.Controls.Add(this.textBox1);
            this.uefiflash.Controls.Add(this.button2);
            this.uefiflash.Controls.Add(this.checkBox2);
            this.uefiflash.Controls.Add(this.checkBox1);
            this.uefiflash.Controls.Add(this.skipsigchk);
            this.uefiflash.Controls.Add(this.uefibrowse);
            this.uefiflash.Controls.Add(this.uefiflashlocation);
            this.uefiflash.Controls.Add(this.type);
            this.uefiflash.Location = new System.Drawing.Point(12, 12);
            this.uefiflash.Name = "uefiflash";
            this.uefiflash.Size = new System.Drawing.Size(372, 308);
            this.uefiflash.TabIndex = 0;
            this.uefiflash.TabStop = false;
            this.uefiflash.Text = "UEFI Flash";
            // 
            // emergency
            // 
            this.emergency.Controls.Add(this.button22);
            this.emergency.Controls.Add(this.button6);
            this.emergency.Controls.Add(this.checkBox6);
            this.emergency.Controls.Add(this.checkBox5);
            this.emergency.Controls.Add(this.button5);
            this.emergency.Controls.Add(this.textBox5);
            this.emergency.Controls.Add(this.button4);
            this.emergency.Controls.Add(this.textBox4);
            this.emergency.Controls.Add(this.button3);
            this.emergency.Controls.Add(this.textBox3);
            this.emergency.Controls.Add(this.label4);
            this.emergency.Controls.Add(this.label3);
            this.emergency.Controls.Add(this.label2);
            this.emergency.Controls.Add(this.button1);
            this.emergency.Location = new System.Drawing.Point(390, 12);
            this.emergency.Name = "emergency";
            this.emergency.Size = new System.Drawing.Size(376, 239);
            this.emergency.TabIndex = 1;
            this.emergency.TabStop = false;
            this.emergency.Text = "Qualcomm Emergency Flash";
            // 
            // rnd
            // 
            this.rnd.Controls.Add(this.button10);
            this.rnd.Controls.Add(this.button9);
            this.rnd.Controls.Add(this.button8);
            this.rnd.Controls.Add(this.button7);
            this.rnd.Location = new System.Drawing.Point(8, 326);
            this.rnd.Name = "rnd";
            this.rnd.Size = new System.Drawing.Size(376, 206);
            this.rnd.TabIndex = 2;
            this.rnd.TabStop = false;
            this.rnd.Text = "RnD Debug Options";
            // 
            // etc
            // 
            this.etc.Controls.Add(this.button23);
            this.etc.Controls.Add(this.button21);
            this.etc.Controls.Add(this.button20);
            this.etc.Controls.Add(this.button19);
            this.etc.Controls.Add(this.button18);
            this.etc.Controls.Add(this.button17);
            this.etc.Controls.Add(this.button16);
            this.etc.Controls.Add(this.button15);
            this.etc.Controls.Add(this.button14);
            this.etc.Controls.Add(this.button12);
            this.etc.Controls.Add(this.button13);
            this.etc.Controls.Add(this.button11);
            this.etc.Location = new System.Drawing.Point(390, 257);
            this.etc.Name = "etc";
            this.etc.Size = new System.Drawing.Size(376, 275);
            this.etc.TabIndex = 3;
            this.etc.TabStop = false;
            this.etc.Text = "Other Function";
            // 
            // type
            // 
            this.type.FormattingEnabled = true;
            this.type.Items.AddRange(new object[] {
            "FFU File",
            "Partition Image File",
            "eMMC Image File",
            "VPL File"});
            this.type.Location = new System.Drawing.Point(6, 27);
            this.type.Name = "type";
            this.type.Size = new System.Drawing.Size(121, 26);
            this.type.TabIndex = 0;
            this.type.SelectedIndexChanged += new System.EventHandler(this.type_SelectedIndexChanged);
            // 
            // uefiflashlocation
            // 
            this.uefiflashlocation.Location = new System.Drawing.Point(133, 27);
            this.uefiflashlocation.Name = "uefiflashlocation";
            this.uefiflashlocation.Size = new System.Drawing.Size(148, 28);
            this.uefiflashlocation.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(-39, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(27, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // uefibrowse
            // 
            this.uefibrowse.Location = new System.Drawing.Point(287, 27);
            this.uefibrowse.Name = "uefibrowse";
            this.uefibrowse.Size = new System.Drawing.Size(75, 28);
            this.uefibrowse.TabIndex = 2;
            this.uefibrowse.Text = "Browse";
            this.uefibrowse.UseVisualStyleBackColor = true;
            // 
            // skipsigchk
            // 
            this.skipsigchk.AutoSize = true;
            this.skipsigchk.Location = new System.Drawing.Point(6, 123);
            this.skipsigchk.Name = "skipsigchk";
            this.skipsigchk.Size = new System.Drawing.Size(214, 22);
            this.skipsigchk.TabIndex = 3;
            this.skipsigchk.Text = "Skip Signature Check";
            this.skipsigchk.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(6, 151);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(196, 22);
            this.checkBox1.TabIndex = 4;
            this.checkBox1.Text = "Skip PLAT ID Check";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(6, 179);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(241, 22);
            this.checkBox2.TabIndex = 5;
            this.checkBox2.Text = "Skip Backup and Restore";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(247, 257);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(115, 36);
            this.button2.TabIndex = 6;
            this.button2.Text = "Execute";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(146, 61);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(216, 28);
            this.textBox1.TabIndex = 8;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(6, 95);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(205, 22);
            this.checkBox3.TabIndex = 0;
            this.checkBox3.Text = "Change Product Code";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(220, 95);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(142, 28);
            this.textBox2.TabIndex = 9;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(6, 207);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(124, 22);
            this.checkBox4.TabIndex = 10;
            this.checkBox4.Text = "Skip Flash";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 18);
            this.label1.TabIndex = 11;
            this.label1.Text = "Partition Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 18);
            this.label2.TabIndex = 12;
            this.label2.Text = "HEX File";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 18);
            this.label3.TabIndex = 13;
            this.label3.Text = "MBN File";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 18);
            this.label4.TabIndex = 14;
            this.label4.Text = "ED File";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(295, 25);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 28);
            this.button3.TabIndex = 13;
            this.button3.Text = "Browse";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(92, 25);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(197, 28);
            this.textBox3.TabIndex = 12;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(295, 61);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 28);
            this.button4.TabIndex = 16;
            this.button4.Text = "Browse";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(92, 61);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(197, 28);
            this.textBox4.TabIndex = 15;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(295, 95);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 28);
            this.button5.TabIndex = 18;
            this.button5.Text = "Browse";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(92, 95);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(197, 28);
            this.textBox5.TabIndex = 17;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(6, 129);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(133, 22);
            this.checkBox5.TabIndex = 12;
            this.checkBox5.Text = "Rewrite GPT";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(6, 157);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(124, 22);
            this.checkBox6.TabIndex = 19;
            this.checkBox6.Text = "Define FFU";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(255, 193);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(115, 36);
            this.button6.TabIndex = 12;
            this.button6.Text = "Execute";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(6, 27);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(364, 36);
            this.button7.TabIndex = 12;
            this.button7.Text = "Reboot to UEFI Flash App";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(6, 69);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(364, 36);
            this.button8.TabIndex = 13;
            this.button8.Text = "Reboot to MMOS";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(6, 111);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(364, 36);
            this.button9.TabIndex = 14;
            this.button9.Text = "Reboot to Mass Storage Mode";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(6, 153);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(364, 36);
            this.button10.TabIndex = 15;
            this.button10.Text = "Perform RnD Authentication";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(9, 69);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(176, 36);
            this.button11.TabIndex = 16;
            this.button11.Text = "Reboot Phone";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(9, 111);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(176, 36);
            this.button12.TabIndex = 17;
            this.button12.Text = "Power Off";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(9, 27);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(176, 36);
            this.button13.TabIndex = 18;
            this.button13.Text = "USB Device Check";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(6, 235);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(196, 22);
            this.checkBox7.TabIndex = 12;
            this.checkBox7.Text = "Do Full NVI Update";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(6, 263);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(178, 22);
            this.checkBox8.TabIndex = 13;
            this.checkBox8.Text = "Do Factory Reset";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(9, 153);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(176, 36);
            this.button14.TabIndex = 19;
            this.button14.Text = "Firmware Browser";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(194, 27);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(176, 36);
            this.button15.TabIndex = 20;
            this.button15.Text = "Advanced IUTool";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(194, 69);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(176, 36);
            this.button16.TabIndex = 21;
            this.button16.Text = "Advanced FFUTool";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(194, 111);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(176, 36);
            this.button17.TabIndex = 22;
            this.button17.Text = "Extract FFU";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(194, 153);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(176, 36);
            this.button18.TabIndex = 23;
            this.button18.Text = "Repack FFU";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(9, 195);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(176, 36);
            this.button19.TabIndex = 24;
            this.button19.Text = "FFU Reader";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(194, 195);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(176, 36);
            this.button20.TabIndex = 25;
            this.button20.Text = "Device Dumper";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(9, 237);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(176, 36);
            this.button21.TabIndex = 26;
            this.button21.Text = "View Log";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(9, 193);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(240, 36);
            this.button22.TabIndex = 27;
            this.button22.Text = "Reboot to EDL Mode";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(194, 239);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(176, 36);
            this.button23.TabIndex = 27;
            this.button23.Text = "More";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // thor2gui
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(778, 544);
            this.Controls.Add(this.etc);
            this.Controls.Add(this.rnd);
            this.Controls.Add(this.emergency);
            this.Controls.Add(this.uefiflash);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "thor2gui";
            this.Opacity = 0.9D;
            this.Text = "Advanced WDFT";
            this.uefiflash.ResumeLayout(false);
            this.uefiflash.PerformLayout();
            this.emergency.ResumeLayout(false);
            this.emergency.PerformLayout();
            this.rnd.ResumeLayout(false);
            this.etc.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox uefiflash;
        private System.Windows.Forms.ComboBox type;
        private System.Windows.Forms.GroupBox emergency;
        private System.Windows.Forms.GroupBox rnd;
        private System.Windows.Forms.GroupBox etc;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox skipsigchk;
        private System.Windows.Forms.Button uefibrowse;
        private System.Windows.Forms.TextBox uefiflashlocation;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button11;
    }
}

